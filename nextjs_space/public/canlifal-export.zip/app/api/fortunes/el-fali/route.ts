import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'
import { checkIpFortuneAccess, checkRegisteredFortuneAccess, getClientIp } from '@/lib/fortune-access'
import prisma from '@/lib/db'
import { callLLM } from '@/lib/llm'
import { checkAndDeductCredits } from '@/lib/credit-checker'
import { autoShareFortune } from '@/lib/social-helper'
import { getFileUrl } from '@/lib/s3'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    // Parse body once
    const body = await request.json().catch(() => ({}))
    const adWatched = body?.adWatched === true

    // Access control: IP-based for unregistered, CFC for registered
    if (!session?.user?.id) {
      const ip = getClientIp(request)
      const ipAccess = await checkIpFortuneAccess(ip, adWatched)
      if (!ipAccess.allowed) {
        return NextResponse.json({ error: ipAccess.message, reason: ipAccess.reason }, { status: 403 })
      }
    }

    const { palmImagePath, hand, language } = body

    if (!palmImagePath) {
      return NextResponse.json({ error: 'El fotoğrafı gereklidir' }, { status: 400 })
    }

    // Check and deduct credits (skip if ad watched or unregistered)
    if (session?.user?.id && !adWatched) {
      const creditResult = await checkAndDeductCredits(session.user.id, 'palm')
      if (!creditResult.success) {
        return NextResponse.json({ error: creditResult.message, reason: 'needs_cfc' }, { status: 403 })
      }
    }

    const palmImageUrl = await getFileUrl(palmImagePath, false)
    const handText = hand === 'left' ? ('sol el') : ('sağ el')

    const systemPrompt = `Sen deneyimli bir el falcısın (palmist). Kullanıcının ${handText} görselini analiz et. Yaşam çizgisi, kalp çizgisi, kader çizgisi, akıl çizgisi ve diğer önemli çizgileri yorumla. Kişilik, aşk hayatı, kariyer, sağlık ve gelecek hakkında detaylı bilgi ver. Cevabın 350-450 kelime arasında, mistik ve aydınlatıcı olmalı. Tamamen Türkçe cevap ver.`

    const messages = [
      { role: 'system', content: systemPrompt },
      { 
        role: 'user', 
        content: [
          { type: 'text', text: 'Lütfen elimin fotoğrafını analiz et ve el falımı söyle.' },
          { type: 'image_url', image_url: { url: palmImageUrl } }
        ]
      },
    ]

    const response = await callLLM({ messages, max_tokens: 700 })

    if (!response?.ok) throw new Error('Yapay zeka servisi yanıt vermedi')

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response?.body?.getReader()
        const decoder = new TextDecoder()
        const encoder = new TextEncoder()
        let fullResponse = ''

        try {
          while (true) {
            const { done, value } = (await reader?.read()) ?? { done: true, value: undefined }
            if (done) break
            
            const chunk = decoder.decode(value, { stream: true })
            const lines = chunk.split('\n').filter(line => line.trim() !== '')
            
            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6)
                if (data === '[DONE]') {
                  if (session?.user?.id) {
                  const fortune = await prisma.fortune.create({
                    data: {
                      userId: session.user.id,
                      fortuneType: 'palm',
                      inputData: JSON.stringify({ palmImagePath, hand }),
                      aiResponse: fullResponse,
                      language: language || 'en',
                    },
                  })
                  await autoShareFortune(session.user.id, fortune.id, 'palm', fullResponse, language || 'en')
                    
                  } else {
                    // Auto-share guest fortune to social feed
                    await autoShareFortune(null, null, 'palm', fullResponse, language || 'en')
                  }

                  continue
                }
                try {
                  const parsed = JSON.parse(data)
                  const content = parsed?.choices?.[0]?.delta?.content || ''
                  if (content) fullResponse += content
                } catch (e) {}
              }
            }
            controller.enqueue(encoder.encode(chunk))
          }
        } catch (error) {
          controller.error(error)
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' },
    })
  } catch (error) {
    console.error('Palm reading error:', error)
    return NextResponse.json({ error: 'El falı oluşturulamadı. Lütfen tekrar deneyin.' }, { status: 500 })
  }
}
